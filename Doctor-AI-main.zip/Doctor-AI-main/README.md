# Doctor-AI
Doctor AI est une application de santé intelligente intégrant IA, simulation médicale 3D et réalité augmentée. Elle aide à comprendre les maladies, simuler des opérations, suivre les traitements et accéder aux pharmacies, tout en favorisant la prévention et l’éducation médicale.
