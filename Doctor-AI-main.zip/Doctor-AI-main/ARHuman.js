import React from 'react';
import { ViroARScene, Viro3DObject } from '@viro-community/react-viro';

export default function ARHuman() {
  return (
    <ViroARScene>
      <Viro3DObject
        source={require('./assets/human.glb')}
        position={[0, 0, -1]}
        scale={[0.2, 0.2, 0.2]}
        type="GLB"
      />
    </ViroARScene>
  );
}
