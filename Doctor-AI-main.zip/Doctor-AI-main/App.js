import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from './screens/HomeScreen';
import Model3D from './screens/Model3D';
import ARScreen from './screens/ARScreen';
import ReminderScreen from './screens/ReminderScreen';
import PharmacyScreen from './screens/PharmacyScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="3D" component={Model3D} />
        <Stack.Screen name="AR" component={ARScreen} />
        <Stack.Screen name="Reminder" component={ReminderScreen} />
        <Stack.Screen name="Pharmacy" component={PharmacyScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
