import React from 'react';
import { GLView } from 'expo-gl';
import * as THREE from 'three';
import { Renderer } from 'expo-three';
import { Asset } from 'expo-asset';

export default function ModelViewer() {
  return (
    <GLView
      style={{ flex: 1 }}
      onContextCreate={async (gl) => {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
        camera.position.z = 3;

        const renderer = new Renderer({ gl });

        const light = new THREE.PointLight(0xffffff, 1);
        light.position.set(5, 5, 5);
        scene.add(light);

        // Charger modèle 3D
        const asset = Asset.fromModule(require('./assets/human.glb'));
        await asset.downloadAsync();

        const loader = new THREE.GLTFLoader();
        const gltf = await loader.loadAsync(asset.localUri);

        const model = gltf.scene;
        scene.add(model);

        function render() {
          requestAnimationFrame(render);
          model.rotation.y += 0.01;
          renderer.render(scene, camera);
          gl.endFrameEXP();
        }

        render();
      }}
    />
  );
}
