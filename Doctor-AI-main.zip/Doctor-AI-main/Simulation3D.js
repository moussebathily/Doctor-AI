import React, { useRef } from "react";
import { GLView } from "expo-gl";
import { Renderer } from "expo-three";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";

export default function Simulation3D() {
  return (
    <GLView
      style={{ flex: 1 }}
      onContextCreate={async (gl) => {
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0f1c);

        const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
        camera.position.z = 2;

        const renderer = new Renderer({ gl });

        // 💡 Lumière réaliste
        const light1 = new THREE.DirectionalLight(0xffffff, 1);
        light1.position.set(5, 5, 5);
        scene.add(light1);

        const light2 = new THREE.AmbientLight(0x404040);
        scene.add(light2);

        // 🔥 Charger vrai modèle anatomique
        const loader = new GLTFLoader();
        const model = await loader.loadAsync(
          "https://model-url.glb"
        );

        scene.add(model.scene);

        function animate() {
          requestAnimationFrame(animate);

          model.scene.rotation.y += 0.003;

          renderer.render(scene, camera);
          gl.endFrameEXP();
        }

        animate();
      }}
    />
  );
}
